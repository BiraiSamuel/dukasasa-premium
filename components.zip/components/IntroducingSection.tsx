"use client";

import Link from "next/link";
import React from "react";

const IntroducingSection = () => {
  return (
    <section className="py-14 bg-gradient-to-r from-white via-blue-100 to-blue-300 shadow-inner">
      <div className="text-center flex flex-col gap-y-5 items-center px-4">
        <h2 className="text-5xl md:text-6xl font-extrabold text-blue-900 tracking-tight transition-transform duration-300 hover:scale-105">
          INTRODUCING{" "}
          <span className="text-blue-600">SINGITRONIC</span>
        </h2>

        <div className="space-y-1 max-w-2xl mx-auto">
          <p className="text-blue-800 text-lg font-medium">
            Buy the latest electronics — smart, sleek, and future-ready.
          </p>
          <p className="text-blue-800 text-lg font-medium">
            Only the best tech for passionate minds.
          </p>
        </div>

        <Link
          href="/shop"
          className="mt-4 inline-block bg-blue-600 text-white font-bold px-8 py-2 text-base rounded-full shadow-md transition-transform hover:scale-105 hover:bg-blue-700"
        >
          SHOP NOW
        </Link>
      </div>
    </section>
  );
};

export default IntroducingSection;