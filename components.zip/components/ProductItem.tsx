import Image from "next/image";
import Link from "next/link";
import ProductItemRating from "./ProductItemRating";

interface Product {
  id: string;
  title: string;
  slug: string;
  price: number;
  mainImage?: string;
  rating?: number;
}

const ProductItem = ({
  product,
  color,
}: {
  product: Product;
  color: string;
}) => {
  return (
    <div className="flex flex-col items-center gap-y-4 p-5 rounded-xl shadow-lg backdrop-blur-lg bg-blue-200/30 border border-blue-100 w-full max-w-xs transition-transform hover:scale-105">
      <Link
        href={`/product/${product.slug}`}
        title={`View ${product.title}`}
        aria-label={`View details for ${product.title}`}
        className="block w-full"
      >
        <div className="w-full h-64 flex items-center justify-center overflow-hidden rounded-md bg-white/30">
          <Image
            src={product.mainImage ? `/${product.mainImage}` : "/product_placeholder.jpg"}
            alt={product.title}
            width={250}
            height={300}
            className="object-contain w-full h-full"
          />
        </div>
      </Link>

      <div className="text-center w-full text-gray-900">
        <Link
          href={`/product/${product.slug}`}
          className="text-lg font-semibold tracking-tight line-clamp-2"
        >
          {product.title}
        </Link>

        <p className="mt-1 text-lg font-bold text-blue-700">
          Ksh. {product.price.toFixed(2)}
        </p>

        <div className="my-2">
          <ProductItemRating productRating={product?.rating} />
        </div>

        <Link
          href={`/product/${product.slug}`}
          className="inline-flex justify-center items-center w-full mt-2 uppercase px-4 py-2 border border-blue-300 font-bold text-blue-600 bg-white/70 hover:bg-white/90 rounded-md transition focus:ring-2 focus:ring-offset-2 focus:ring-blue-400"
        >
          View Product
        </Link>
      </div>
    </div>
  );
};

export default ProductItem;