"use client";
import { useRouter } from "next/navigation";
import React, { useState } from "react";

const SearchInput = () => {
  const [searchInput, setSearchInput] = useState<string>("");
  const router = useRouter();

  const searchProducts = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!searchInput.trim()) return;
    router.push(`/search?search=${encodeURIComponent(searchInput.trim())}`);
    setSearchInput("");
  };

  return (
    <form
      onSubmit={searchProducts}
      className="flex w-full max-w-xl mx-auto rounded-full shadow-md overflow-hidden border border-gray-300 focus-within:ring-2 focus-within:ring-blue-500 transition"
      role="search"
      aria-label="Search products"
    >
      <input
        type="text"
        value={searchInput}
        onChange={(e) => setSearchInput(e.target.value)}
        placeholder="Search for products..."
        className="flex-1 px-4 py-2 text-sm text-gray-800 focus:outline-none bg-gray-100 placeholder-gray-400"
        aria-label="Search input"
      />
      <button
        type="submit"
        className="bg-blue-500 text-white px-5 py-2 text-sm font-semibold hover:bg-blue-600 transition-colors"
        aria-label="Search"
      >
        Search
      </button>
    </form>
  );
};

export default SearchInput;