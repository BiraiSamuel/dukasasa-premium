"use client";

import { useEffect, useState } from "react";
import ProductItem from "./ProductItem";
import Heading from "./Heading";

const ProductsSection = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const res = await fetch("http://localhost:3001/api/products");
        if (!res.ok) throw new Error("Failed to fetch products");
        const data = await res.json();
        setProducts(data);
      } catch (err: any) {
        console.error("Fetch error:", err);
        setError("Unable to load products. Please try again later.");
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);

  return (
    <section className="bg-gradient-to-br from-blue-600 to-blue-500 text-white border-t-4 border-white py-20">
      <div className="max-w-screen-2xl mx-auto px-4 sm:px-6 lg:px-10">
        <Heading title="FEATURED PRODUCTS" />

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-6 mt-10">
          {loading ? (
            Array.from({ length: 8 }).map((_, idx) => (
              <div
                key={idx}
                className="animate-pulse bg-white/10 rounded-lg h-[300px] w-full"
              ></div>
            ))
          ) : error ? (
            <p className="col-span-full text-red-300 text-center font-semibold">
              {error}
            </p>
          ) : products.length === 0 ? (
            <p className="col-span-full text-center text-white text-lg">
              No products available.
            </p>
          ) : (
            products.map((product) => (
              <div key={product.id} className="transition-transform hover:scale-[1.03]">
                <ProductItem product={product} color="white" />
              </div>
            ))
          )}
        </div>
      </div>
    </section>
  );
};

export default ProductsSection;