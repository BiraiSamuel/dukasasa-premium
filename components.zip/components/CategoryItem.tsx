// *********************
// Role of the component: Category Item that will display category icon, category name and link to the category
// Name of the component: CategoryItem.tsx
// Developer: Aleksandar Kuzmanovic
// Version: 1.1
// Component call: <CategoryItem title={title} href={href} ><Image /></CategoryItem>
// Input parameters: CategoryItemProps interface
// Output: Category icon, category name and link to the category
// *********************

import Link from "next/link";
import React, { type ReactNode } from "react";

interface CategoryItemProps {
  children: ReactNode;
  title: string;
  href: string;
}

const CategoryItem = ({ title, children, href }: CategoryItemProps) => {
  return (
    <Link href={href} className="transition-transform hover:scale-105">
      <div className="flex flex-col items-center gap-y-3 cursor-pointer bg-white py-6 px-4 rounded-xl shadow-md hover:shadow-lg hover:bg-gray-50 transition-all duration-300">
        <div className="w-20 h-20 flex items-center justify-center bg-blue-100 rounded-full p-3">
          {children}
        </div>
        <h3 className="font-semibold text-lg text-center text-blue-700 tracking-wide">
          {title}
        </h3>
      </div>
    </Link>
  );
};

export default CategoryItem;