// app/(shop)/shop/[...slug]/page.tsx

export const dynamic = "force-dynamic";
export const revalidate = 0;

import {
  Breadcrumb,
  Filters,
  Pagination,
  Products,
  SortBy,
} from "@/components";
import React from "react";

// Format slug into readable category text
const improveCategoryText = (text: string): string => {
  const readable = text.replace(/-/g, " ");
  return readable.charAt(0).toUpperCase() + readable.slice(1);
};

const ShopPage = ({ params }: { params: { slug?: string[] } }) => {
  const category = params?.slug?.[0] ?? "";

  return (
    <div className="bg-white text-black py-10">
      <div className="max-w-screen-2xl mx-auto px-6 sm:px-8 md:px-10">
        <Breadcrumb />

        <div className="grid grid-cols-1 md:grid-cols-[250px_1fr] gap-8">
          {/* Sidebar filters */}
          <aside>
            <Filters />
          </aside>

          {/* Product content */}
          <main>
            <div className="flex justify-between items-center flex-wrap gap-y-3 mb-6">
              <h1 className="text-2xl sm:text-3xl font-bold uppercase">
                {category
                  ? improveCategoryText(category)
                  : "All Products"}
              </h1>
              <SortBy />
            </div>

            <div className="border-t pt-4">
              <Products slug={params} />
            </div>

            <Pagination />
          </main>
        </div>
      </div>
    </div>
  );
};

export default ShopPage;