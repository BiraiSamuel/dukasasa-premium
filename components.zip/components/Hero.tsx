"use client";

import Image from "next/image";
import React from "react";

const Hero = () => {
  return (
    <section
      className="w-full bg-gradient-to-br from-blue-50 via-blue-100 to-blue-200 py-20"
      aria-label="Hero section"
    >
      <div className="max-w-screen-2xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 items-center gap-16">
        
        {/* Text Content */}
        <div className="flex flex-col gap-6 text-center lg:text-left font-sans">
          <h1 className="text-5xl md:text-6xl font-extrabold text-blue-900 leading-tight tracking-tight">
            The Product of the Future
          </h1>
          <p className="text-lg md:text-xl text-blue-800/90 max-w-xl mx-auto lg:mx-0">
            Discover wearable innovation. Sleek design. Smart features. Everything you need—right on your wrist.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start mt-4">
            <button
              type="button"
              className="bg-blue-600 text-white font-semibold px-8 py-3 rounded-full shadow hover:bg-blue-700 transition"
            >
              Buy Now
            </button>
            <button
              type="button"
              className="bg-white text-blue-600 font-semibold px-8 py-3 rounded-full border border-blue-300 hover:bg-blue-50 transition"
            >
              Learn More
            </button>
          </div>
        </div>

        {/* Product Image */}
        <div className="flex justify-center lg:justify-end">
          <Image
            src="/watch for banner.png"
            width={500}
            height={500}
            alt="Smart Watch product"
            priority
            className="w-auto h-auto max-w-full drop-shadow-xl"
          />
        </div>
      </div>
    </section>
  );
};

export default Hero;