// app/(admin)/layout.tsx
import { getServerSession } from "next-auth"
import { authOptions } from "@/app/api/auth/[...nextauth]/route"
import { redirect } from "next/navigation"
import { ReactNode } from "react"

export default async function Layout({ children }: { children: ReactNode }) {
  const session = await getServerSession(authOptions)

  if (!session || !session.user?.email) {
    redirect("/")
  }

  const email = encodeURIComponent(session.user.email)

  const res = await fetch(`http://localhost:3001/api/users/email/${email}`, {
    cache: "no-store",
  })

  if (!res.ok) {
    // Handle bad fetch or fallback
    redirect("/")
  }

  const data = await res.json()

  if (data.role !== "admin") {
    redirect("/")
  }

  return <>{children}</>
}